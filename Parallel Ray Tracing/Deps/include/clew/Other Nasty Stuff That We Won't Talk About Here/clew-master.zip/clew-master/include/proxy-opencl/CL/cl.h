// allows us to provide clew to clBLAS etc, which expect to find include 
// files as include/CL/cl.h, somewhere

#include "clew.h"

